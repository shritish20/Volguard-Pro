
from fastapi import APIRouter
from models.schemas import AccessToken, VolguardResult
from utils.option_chain import get_volguard_metrics

router = APIRouter()

@router.post("/run", response_model=VolguardResult)
def run_volguard(input: AccessToken):
    access_token = input.access_token
    result = get_volguard_metrics(access_token)
    return result
