
from pydantic import BaseModel
from typing import List, Optional

class AccessToken(BaseModel):
    access_token: str

class VolguardResult(BaseModel):
    nifty_spot: float
    atm_strike: float
    atm_iv: float
    straddle_price: float
    pcr: float
    max_pain: float
    expiry: str
    timestamp: str

class ForecastResult(BaseModel):
    date: str
    day: str
    forecasted_volatility: float

class PredictionRequest(BaseModel):
    atm_iv: float
    realized_vol: float
    ivp: float
    event_impact_score: float
    fii_dii_net_long: float
    pcr: float
    vix: float

class PredictionResponse(BaseModel):
    predicted_volatility: float

class StrategyRequest(BaseModel):
    access_token: str
    strategy_name: str
    quantity: int
    spot_price: float

class StrategyResponse(BaseModel):
    status: str
    pnl: float
    capital_used: float
    entry_price: float
