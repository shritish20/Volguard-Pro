
from datetime import datetime

def get_volguard_metrics(access_token: str):
    spot = 22370.25
    atm = round(spot / 50) * 50
    atm_iv = 14.7
    straddle_price = 260
    pcr = 0.89
    max_pain = 22500
    expiry = "2025-05-22"
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return {
        "nifty_spot": spot,
        "atm_strike": atm,
        "atm_iv": atm_iv,
        "straddle_price": straddle_price,
        "pcr": pcr,
        "max_pain": max_pain,
        "expiry": expiry,
        "timestamp": timestamp
    }
