
from fastapi import FastAPI
from routers import run_volguard, forecast, prediction, strategy, user

app = FastAPI(
    title="VolGuard Pro API",
    description="AI-powered Option Selling Copilot for Indian Markets",
    version="2.0"
)

app.include_router(run_volguard.router, prefix="/volguard", tags=["Volatility Engine"])
app.include_router(forecast.router, prefix="/forecast", tags=["GARCH Forecast"])
app.include_router(prediction.router, prefix="/predict", tags=["XGBoost Volatility Prediction"])
app.include_router(strategy.router, prefix="/strategy", tags=["Strategy Builder"])
app.include_router(user.router, prefix="/user", tags=["User Data"])

@app.get("/")
def root():
    return {"message": "VolGuard Pro API is live and working"}
